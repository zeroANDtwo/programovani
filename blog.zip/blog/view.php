<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <link href="css/style.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">




    <?php 
include_once 'config/Database.php';
include_once 'class/Articles.php';
$database = new Database();
$db = $database->getConnection();
$article = new Articles($db);
$article->id = (isset($_GET['id']) && $_GET['id']) ? $_GET['id'] : '0';
$result = $article->getArticles();
$post = $result->fetch_assoc();
?>
    <?php
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

    <meta name="robots" content="index, follow">
    <link rel="icon" href="hacker.ico" type="image/x-icon" sizes="16x16">
    <meta name="description" content="<?php echo $post['description']; ?>">
    <meta name="keywords" content="<?php echo $post['klicovaslova'];?>">
    <meta name="author" content="AFFILY">
    <title><?php echo $post['metatitle']; ?></title>


</head>

<body>
    <div class="container">
        <div id="blog" class="row">
            <div class="topnav" id="myTopnav">
                <a href="https://www.kyberneticky-utok.cz" class="active" title="kybernetický útok"><img
                        src="hacking.png">
                    AFFILY
                </a>
                <a href="https://www.kyberneticky-utok.cz">Domů</a>
                <a href="https://www.kyberneticky-utok.cz/#slide07">Kontakt</a>
                <a href="https://www.kyberneticky-utok.cz/#slide03">Služby</a>
                <a href="https://www.blog.kyberneticky-utok.cz">Blog</a>
                <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                    <i class="fa fa-bars"></i>
                </a>
            </div>
            <?php 
			$date = date_create($post['created']);
			$message = str_replace("\n\r", "<br><br>", $post['message']);
		?>
            <div class="col-md-10 blogShort">
                <h2><?php echo $post['title']; ?></h2>
                <em><strong>Publikováno dne</strong>: <?php echo date_format($date, "Y-m-d");	?></em>
                <br><br>
                <article>
                    <p><?php echo $message; ?> </p>
                </article>
                <p>email: info@kyberneticky-utok.cz</p>
                <p>telefon: +420 721 122 042</p>
                <a href="https://www.blog.kyberneticky-utok.cz">přejděte na webové stránky</a>
                <br><br>
                <a class="twitter" target="_blank"
                    href="https://twitter.com/share?url=<?php echo $actual_link ?>&text=<?php echo $post['title']; ?>"><img
                        src="image/twitter.png"></a>
                <a class="facebook" target="_blank"
                    href="https://www.facebook.com/sharer/sharer.php?s=<?php echo $actual_link ?>&t=<?php echo $post['title']; ?>"><img
                        src="image/facebook.png"></a>
                <br></br>
            </div>
            <div class="col-md-12 gap10"></div>
        </div>
    </div>
    <div class="insert-post-ads1" style="margin-top:20px;"></div>
    <br>
    <p style="text-align:center">autorská práva &copy; 2020 AFFILY
        | Návrh <a rel="nofollow" href="https://www.tvorba-webovych-stranek-marketing.cz">tworba webových stránek</a>
    </p>

    <script>
    function myFunction() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
            x.className += " responsive";
        } else {
            x.className = "topnav";
        }
    }
    </script>
</body>

</html>